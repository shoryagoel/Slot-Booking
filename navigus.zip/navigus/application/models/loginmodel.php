<?php
class Loginmodel extends CI_Model{
    public function user_valid( $username, $password ){
        $q =  $this->db->where(['uname'=>$username,'password'=>$password])
                       ->get('users');
        if($q->num_rows()){
            $this->session->set_userdata('id',$q->row()->uname);
            return 'user';
        }
        else{
            $q =  $this->db->where(['email'=>$username,'password'=>$password])
                       ->get('admin');
            if($q->num_rows()){
            $this->session->set_userdata('id',$q->row()->email);
            return "admin";
            }else{
                return FALSE;
            }
        }   
    }
    
    
    public function create_user($username,$email, $password) {
        $q =  $this->db->insert('users',['uname'=>$username,'email'=>$email,'password'=>$password]);
        if($q){
            return TRUE;
        }else{
            return FALSE;
        }
    }
    
    public function get_data() {
        $id = $this->session->userdata('id');
        $q = $this->db->where('uname',$id)->get('slot');
        return $q->result_array();
    }
    
    public function get_time($date) {
        $q = $this->db->where('date',$date)->get('slot');
        return $q->result_array();
    }
    public function book($title,$date,$time) {
        $username= $this->session->userdata('id');
        $q =  $this->db->insert('slot',['uname'=>$username,'title'=>$title,'date'=>$date,'time'=>$time]);
        if($q){
            return TRUE;
        }else{
            return FALSE;
        }
    }
    
    public function get_all_data() {
        $q = $this->db->order_by('date', 'asc')->get('slot');
        return $q->result_array();
    }
}

?>