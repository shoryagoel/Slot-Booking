<?php include('public_header_signup.php'); ?>
<head><title>Login</title></head>
<body>
	<style>
	body{
    margin: 0;
    padding: 0;
    background-color:#e9fae8;
    background-size: cover;
    background-position: center;
    font-family: Times New Roman, Times, serif;
}
.login-box{
    width: 400px;
    height: 450px;
    background: rgba(29, 189, 204, 0.5);
    color: #fff;
    top: 50%;
    left: 50%;
    position: absolute;
    transform: translate(-50%,-50%);
    box-sizing: border-box;
    padding: 70px 30px;
}
.avatar{
    width: 100px;
    height: 100px;
    border-radius: 50%;
    position: absolute;
    top: -50px;
    left: calc(50% - 50px);
}
h3{
    margin: 0;
    padding: 0 0 20px;
    text-align: center;
    font-size: 22px;
}
.login-box p{
    margin: 0;
    padding: 0;
    font-size: 20px;
}
.login-box input{
    width: 100%;
    margin-bottom: 20px;
}
.login-box input[type="text"], input[type="password"]
{
    border: none;
    border-bottom: 1px solid #fff;
    background: transparent;
    outline: none;
    height: 40px;
    color: #fff;
    font-size: 16px;
}
.login-box input[type="submit"]
{
    border: none;
    outline: none;
	margin-top:20px;
    height: 40px;
    background: Yellow;
    color: #000;
    font-size: 18px;
    border-radius: 20px;
}
.login-box input[type="submit"]:hover
{
    cursor: pointer;
    background: #39dc79;
    color: #000;
}
.login-box a{
    text-decoration: none;
    font-size: 16px;
    color:#fff;
}
.login-box a:hover
{
    color: Yellow;
}
span{
	color:#faf146;
}
</style>
    <div class="login-box">
    <?php $path = base_url("images/avatar"); ?>    
    <img src="<?php echo $path;?>" class="avatar">
        <h3><span>LOGIN </span>PANEL</h3>
        <?php if(!empty($success)){echo $success;}?>
        <?php if(!empty($error)){echo $error;}?>
            <?php echo form_open("login/user_login"); ?>
            <p>User ID:</p>
            <?php echo form_input(['type'=>"text",'name'=>"username",'placeholder'=>"Enter Username"]); ?>
            <p>Password:</p>
            <?php echo form_input(['type'=>"password",'name'=>"password",'placeholder'=>"Enter Password"]); ?>
            <?php echo form_submit(['name'=>"submit" ,'value'=>"Submit"]); ?>
    </div>
    
    </body>
<?php include('public_footer.php'); ?>