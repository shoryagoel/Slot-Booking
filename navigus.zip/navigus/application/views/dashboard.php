<html>
<head>
<title>Dashboard</title>
</head>
<style>
*{
	margin:0px;
}
.navbar{
	overflow:hidden;
	position:fixed;
	width:100%;
	background-color:grey;
	height:50px;
	top:0;
}
h5{
	color:white;
	margin-top:10px;
	font-size:20px;
	margin-left:5%;
}
#container_1{
	float:left;
	margin-top:50px;
	width:30%;
	background-color:lightgreen;
	height:100%;
}
.btn {
  background-color: green;
  color: white;
  font-size:18px;
  margin-top:30px;
  padding: 15px 20px;
  border: none;
  cursor: pointer;
  width: 50%;
  margin-left:25%;
  border-radius:25px;
}
h2{
	margin-top:50px;
	margin-left:40%;
}

.btn:hover {
  background-color:Orange;
  color:black;
  font-size:20;
}
#container_2{
	float:right;
	margin-top:50px;
	background-color:lightblue;
	width:70%;
	height:100%;
}

h4{
	margin-left:20%;
	margin-top:40px;
}
input{
	margin-left:20%;
	margin-top:10px;
	width:300px;
}
span{
	color:#fa0000;
}
h3{
	text-align:center;
}
</style>
<body>
<div class="navbar">
    <a href="<?php echo base_url('user/dashboard');?>"><h5>Dashboard</h5></a>
</div>
<div id="container_1">
    <a href="<?php echo base_url('user/book');?>"><button type="submit" class="btn">Book a slot</button></a>
    <a href="<?php echo base_url('user/booked');?>"><button type="submit" class="btn">Booked slot</button></a>
    <a href="<?php echo base_url('logout');?>"><button type="submit" class="btn">Logout</button></a>
</div>
<div id="container_2">
    <?php if(!empty($success)){echo $success;}?>
<h2><span>WELCOME <?php if(!empty($this->session->userdata('id'))){echo $this->session->userdata('id');}?></span></h2><br><br><br><br><br><br>
<h3>Take an appointment to discuss about project.<br>Here you can book the slot for next 15 days.</h3>
</div>
</body>
</html>
