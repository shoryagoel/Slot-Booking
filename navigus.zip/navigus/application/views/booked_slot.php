<html>
<head>
<title>Booked Slot</title>
</head>
<style>
*{
	margin:0px;
}
.navbar{
	overflow:hidden;
	position:fixed;
	width:100%;
	background-color:grey;
	height:50px;
	top:0;
}
h5{
	color:white;
	margin-top:10px;
	font-size:20px;
	margin-left:5%;
}
#container_1{
	float:left;
	margin-top:50px;
	width:30%;
	background-color:lightgreen;
	height:100%;
}
.btn {
  background-color: green;
  color: white;
  font-size:18px;
  margin-top:30px;
  padding: 15px 20px;
  border: none;
  cursor: pointer;
  width: 50%;
  margin-left:25%;
  border-radius:25px;
}
h2{
	margin-top:30px;;
}

.btn:hover {
  background-color:Orange;
  color:black;
  font-size:20;
}
#container_2{
	float:right;
	margin-top:50px;
	width:70%;
	background-color:lightblue;
	height:100%;
}
container_2.date{
	align:center;
}
.date{
	align:center;
}
h4{
	margin-left:20%;
	margin-top:40px;
}
input{
	margin-left:20%;
	margin-top:10px;
	width:300px;
}
label{
	margin-left:20%;
	margin-top:10px;
	width:300px;
}
table{
	margin-top:30px;
	margin-left:15%;
        border-collapse: collapse;
}
td{
    text-align: center;
}
</style>
<body>
<div class="navbar">
<a href="<?php echo base_url('user/dashboard');?>"><h5>Dashboard</h5></a>
</div>
<div id="container_1">
    <a href="<?php echo base_url('user/book');?>"><button type="submit" class="btn">Book a slot</button></a>
    <a href="<?php echo base_url('user/booked');?>"><button type="submit" class="btn">Booked slot</button></a>
    <a href="<?php echo base_url('logout');?>"><button type="submit" class="btn">Logout</button></a>
</div>
<div id="container_2">
<h2 align="center">Your booked slots</h2>
<table style="width:70%; align:center"border="1px">
    <thead>
        <tr>
        <th>S.no.</th>
        <th>Tilte</th>
        <th>Date</th>
	<th>Time</th>
        </tr>
    </thead>
    <tbody>
    <?php if(!empty($data)){ $sr=1;
     foreach ($data as $value) {?>
    <tr> 
    <td><?php echo $sr ?></td>
    <td><?php echo $value['title']; ?></td>
    <td><?php echo $value['date']; ?></td>
    <td><?php echo $value['time']; ?></td>
    </tr>
    <?php $sr+=1;} }else{?>
    <tr><td colspan="4"><?php echo "No slot is booked till now."; ?></td></tr>
    <?php }?>
    </tbody>
</table>
</div>
</body>
</html>

