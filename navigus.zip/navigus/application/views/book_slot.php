
<html>
<head>
<title>Book Slot</title>
</head>
<style>
*{
	margin:0px;
}
.navbar{
	overflow:hidden;
	position:fixed;
	width:100%;
	background-color:grey;
	height:50px;
	top:0;
}
h5{
	color:white;
	margin-top:10px;
	font-size:20px;
	margin-left:5%;
}
#container_1{
	float:left;
	margin-top:50px;
	width:30%;
	background-color:lightgreen;
	height:100%;
}
.btn {
  background-color: green;
  color: white;
  font-size:18px;
  margin-top:30px;
  padding: 15px 20px;
  border: none;
  cursor: pointer;
  width: 50%;
  margin-left:25%;
  border-radius:25px;
}
h2{
	margin-top:30px;;
}

.btn:hover {
  background-color:Orange;
  color:black;
  font-size:20;
}
#container_2{
	float:right;
	margin-top:50px;
	width:70%;
	background-color:lightblue;
	height:100%;
}
container_2.date{
	align:center;
}
.date{
	align:center;
}
h4{
	margin-left:20%;
	margin-top:40px;
}
input{
	margin-left:20%;
	margin-top:10px;
	width:300px;
	padding:10px;
}
label{
	margin-left:20%;
	margin-top:10px;
	width:300px;
}
input.btn{
	width:150px;
	margin-left:10%;
}
</style>
<body>
<div class="navbar">
<a href="<?php echo base_url('user/dashboard');?>"><h5>Dashboard</h5></a>
</div>
<div id="container_1">
    <a href="<?php echo base_url('user/book');?>"><button type="submit" class="btn">Book a slot</button></a>
    <a href="<?php echo base_url('user/booked');?>"><button type="submit" class="btn">Booked slot</button></a>
    <a href="<?php echo base_url('logout');?>"><button type="submit" class="btn">Logout</button></a>
</div>
<div id="container_2">
<h2 align="center">Select Date & Time for Meeting</h2>
 <?php if(!empty($success)){echo $success;}?>
 <?php if(!empty($error)){echo $error;}?>
<?php echo form_open('user/do_book');?>
<h4>Title</h4>
<!--<input type="text" name="text">-->
<?php echo form_input(['type'=>"text" ,'name'=>"title"]);?>
<h4>Select Date</h4>
      <?php $d = date("Y-m-d");
      $d = date('Y-m-d', time() + 86400);
      $dm = date('Y-m-d', time() + 1296000);
      ?>
<input type="date"  class="date" min=<?php echo $d;?> max=<?php echo $dm;?> name="date"><br><br>
<label for="time"><h4>Select time: </label>
  <select name="time" id="Time">
      <?php $time = array('09:00:00','10:00:00','11:00:00','12:00:00','01:00:00','02:00:00','03:00:00','04:00:00','05:00:00','06:00:00');?>
      <?php foreach ($time as $value) { ?>
          <option value="<?php echo $value;?>"><?php echo $value;?></option>
      <?php } ?>
  </select><br><br>
<?php echo form_submit([ 'class'=>"btn" ,'type'=>"submit" ,'name'=>"submit", 'value'=>"SUBMIT"]); ?>
</div>
</body>
</html>

