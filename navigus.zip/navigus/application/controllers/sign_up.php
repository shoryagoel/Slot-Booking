<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sign_up extends CI_Controller {

	public function index()
	{
            $error = "";
            if(!empty($this->session->userdata("error"))){
                    $error = $this->session->userdata("error");
                    $this->session->unset_userdata("error");
                }
		if(!empty($this->session->userdata("success"))){
                    $success = $this->session->userdata("success");
                    $this->session->unset_userdata("success");
                }else{
                    $success="";
                }
		$this->load->view("signup",['error'=>$error,'success'=>$success]);
	}
        
        public function create_account(){
            $this->form_validation->set_rules('username', 'User Name', 'required|is_unique[users.uname]');
            $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'required');
            if ($this->form_validation->run() === FALSE) {
                $error = validation_errors();
                $this->session->set_userdata('error', $error);
                return redirect('sign_up');
            } else {
                $username = $this->input->post('username');
                $email = $this->input->post('email');
                $password = $this->input->post('password');
                $this->load->model('loginmodel');
                $insert = $this->loginmodel->create_user($username,$email, $password);
                if ($insert){
                    $this->session->set_userdata('success','Account created successfully.');
                    return redirect('login');
                }else{
                    $this->session->set_userdata('success',"Error Occured Please Try Later.");
                    return redirect('sign_up');
                }
            }
}
}

