<?php

class Login extends CI_Controller {

    public function index() {
        $error="";
        if(!empty($this->session->userdata('error'))){
            $error = $this->session->userdata('error');
            $this->session->unset_userdata('error');
        }
        if(!empty($this->session->userdata('success'))){
            $success = $this->session->userdata('success');
            $this->session->unset_userdata('success');
        }else{
            $success = "";
        }
        $this->load->view('admin_login',['error'=>$error,'success'=>$success]);
    }
	public function user_login(){
                $this->form_validation->set_rules('username', 'User Name', 'required');
                $this->form_validation->set_rules('password', 'Password', 'required');
            if ($this->form_validation->run() === FALSE) {
                $error = validation_errors();
                $this->session->set_userdata('error', $error);
                redirect('login');
            } else {
                $username = $this->input->post('username');
                $password = $this->input->post('password');
//                print_r($username,$password);
                $this->load->model('loginmodel');
                $login = $this->loginmodel->user_valid($username, $password);
                if ($login=='user'){
                    return redirect('user/dashboard');
                }elseif ($login=='admin') {
                    return redirect('admin/dashboard');
                }
                else {
                    $this->session->set_userdata('error', 'Invalid Username/Password.');
                    return redirect('login');
                }
        }
	}
}
?>