<?php
class User extends CI_Controller {
    public function dashboard() {
        if(!empty($this->session->userdata('id'))){
        $success="";
        if(!empty($this->session->userdata('success'))){
            $success = $this->session->userdata('success');
            $this->session->unset_userdata('success');
        }
        $this->load->view('dashboard',['success'=>$success]);
        }else{
            return redirect('welcome');
        }
    }
    public function booked() {
        if(!empty($this->session->userdata('id'))){
        $this->load->model('loginmodel');
        $data = $this->loginmodel->get_data();
        $this->load->view('booked_slot',['data'=>$data]);
        }else{
            return redirect('welcome');
        }
    }
    public function book() {
        if(!empty($this->session->userdata('id'))){
        $error="";
        if(!empty($this->session->userdata('error'))){
            $error = $this->session->userdata('error');
            $this->session->unset_userdata('error');
        }
        if(!empty($this->session->userdata('success'))){
            $success = $this->session->userdata('success');
            $this->session->unset_userdata('success');
        }else{
            $success = "";
        }
        $this->load->view('book_slot',['error'=>$error,'success'=>$success]);
        }else{
            return redirect('welcome');
        }
    }
    
    public function do_book() {
          if(!empty($this->session->userdata('id'))){
        $this->form_validation->set_rules('title', 'Title', 'required');
        $this->form_validation->set_rules('date', 'Date', 'required');
        $this->form_validation->set_rules('time', 'Time', 'required');
            if ($this->form_validation->run() === FALSE) {
                $error = validation_errors();
                $this->session->set_userdata('error', $error);
                redirect('user/book');
            } else {
                $title = $this->input->post('title');
                $date = $this->input->post('date');
                $time = $this->input->post('time');
//                print_r($username,$password);
                $this->load->model('loginmodel');
                $data = $this->loginmodel->get_time($date);
//                print_r($data);
                $flag=0;
                if(!empty($data)){
                    foreach ($data as $values){
                        if($values['time']==$time){
                            $flag=1;
                            break;
                        }
                    }
                }
                if($flag==1){
                    $this->session->set_userdata('success', 'This slot is already booked. Please Choose another slot.');
                    return redirect('user/book');
                }else{
                    $login = $this->loginmodel->book($title,$date,$time);
                    if ($login){
                        $this->session->set_userdata('success', 'Slot Booked successfully');
                        return redirect('user/dashboard');
                    }
                    else {
                        $this->session->set_userdata('success', 'Error Occured Please Try Later.');
                        return redirect('user/book');
                    }
                }
        }
        }else{
            return redirect('welcome');
        }
    }
}
?>
