<?php
class Admin extends CI_Controller {
    public function dashboard() {
        if(!empty($this->session->userdata('id'))){
            $this->load->model('loginmodel');
            $data = $this->loginmodel->get_all_data();
            $this->load->view('dashboard_admin',['data'=>$data]);
        }else{
            return redirect('welcome');
        }
    }
}
?>
